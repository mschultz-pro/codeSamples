INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID) 
              VALUES (1000,     'Bandages',  2,           14,                  'Wound Care',1000);

INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID) 
              VALUES (1001,     'Gauze',     13,          100,                 'Wound Care',1001);

INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID)  
              VALUES (1002,     'Ointments', 7,           3,                   'Wound Care',1002);

INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID)  
              VALUES (1003,     'Oxygen Masks',120,       1,                   'Respiratory',1003);

INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID) 
              VALUES (1004,     'Oxygen Tank',185,        3,                   'Respiratory',1004);

INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID) 
              VALUES (1005,     'Scalpel',   27,          5,                   'Surgical',  1005);

INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID) 
              VALUES (1006,     'Mask',      1,           50,                  'Surgical',  1006);

INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID) 
              VALUES (1007,     'Morphine',  1000,        2,                   'Emergency and Trauma',1007);

INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID) 
              VALUES (1008,     'Splint',    57,          1,                   'Emergency and Trauma',1008);

INSERT INTO Supplies (SupplyID, Supply_Name, Supply_Cost, Supply_Quantiy_Used, Supply_Type, FK_VisitID) 
              VALUES (1009,     'Cast',      300,         2,                   'Emergency and Trauma',1009);
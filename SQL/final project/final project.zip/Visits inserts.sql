INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID) 
            VALUES (1000,    '18-Jul-1988 10:47:07','04-Dec-2006 07:37:18',4643,1000,    1008  );
            
INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID) 
            VALUES (1001,    '14-Jan-1987 06:31:43', '30-Jun-1998 05:41:45',1012,1001,   1008  );
            
INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID) 
            VALUES (1002,    '14-Jan-2001 01:02:11','',        '',         1002,         1008 );
            
INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID) 
            VALUES (1003,    '18-Jun-1998 03:56:38','',        '',         1003,           1009  );
            
INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID) 
            VALUES (1004,    '25-Jan-1985 10:04:19','02-Dec-1998 12:06:44',619881,1004,  1009  );
            
INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID)
            VALUES (1005,    '25-Dec-2002 11:34:33','',        '',         1005,         1006  );
            
INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID) 
            VALUES (1006,    '17-Oct-1996 12:51:26','18-Oct-1996 12:51:26',10000,1006,   1006  );
            
INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID) 
            VALUES (1007,    '30-May-2013 06:16:54','30-Jun-2013 11:16:54',61891,1007,   1006  );
          
INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID) 
            VALUES (1008,    '07-Dec-1999 10:30:27','14-Dec-1999 08:30:27',99,1008,      1002  );
            
INSERT INTO Visits (VisitID, Visit_Date, Visit_Discharge_Date, Visit_Cost, FK_PatientID, FK_DepartmentID) 
            VALUES (1009,    '17-Jun-2003 11:45:06','17-Jun-2003 11:45:06','',1009,      1002  );
INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1000,      'Vidya',            'Aleksey','27-Oct-2037 06:28:20','Female',1234567890,'Spond1983@cuvox.de',' 386 West Drive','Kernersville',27284);

INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1001,      'Widald',            'Louise','19-Feb-1972 07:25:24','Female',1234567890,'Havis1969@dayrep.com','36 North Smoky Hollow Ave.','Olympia',98512);

INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1002,      'Khasan',            'Taliesin','31-Dec-2010 02:51:26','Female',1234567890,'Eass1945@superrito.com','45 Marsh Rd.','Merrimack',03054);
              
INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1003,      'Prateek',            'Hyacinth','17-Nov-2002 11:12:27','Female',1234567890,'Shmidecir@armyspy.com','427 University Ave.','Cincinnati',45211);

INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1004,      'Aoife',            'Iliyana','26-Nov-2037 07:12:22','Female',1234567890,'Thars1990@rhyta.com','8246 Beaver Ridge Ave.','Hamilton',45011);

INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1005,      'Dominik',            'Jeronim','23-Jan-1972 10:16:59','Female',1234567890,'Buddard1929@gustr.com','8782 N. Wintergreen Circle','Vicksburg',39180);

INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1006,      'Mordad',            'Dip','09-Jun-1984 10:51:59','Female',1234567890,'Comee1977@cuvox.de','45 Briarwood Ave.','Providence',02904);

INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1007,      'Fleur',            ' Ireneus','23-Dec-2028 01:10:25','Female',1234567890,'Witiet41@teleworm.us','19 Jones Drive','Rosemount',55068);

INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1008,      'Duha',            'Keitha','24-Jun-1994 02:58:56','Female',1234567890,'Harl1984@jourrapide.com','823 Union St.','Woburn',01801);

INSERT INTO Patients (PatientID, Patient_First_Name, Patient_Last_Name, Patient_DOB, Patient_Gender, Patient_Phone, Patient_Email, Patient_Address, Patient_City, Patient_Zip) 
              VALUES (1009,      'Ana',            'Alard','08-Dec-1975 12:52:54','Female',1234567890,'Fals1934@dayrep.com','6 Market Lane','Irvington',07111);

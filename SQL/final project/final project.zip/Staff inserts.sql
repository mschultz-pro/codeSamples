INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1000,    'Mayte',          'Treasure',      1234567890,  'Terson59@rhyta.com','8782 N. Wintergreen Circle','Vicksburg',39180,1000,'East Wing');

INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1001,    'Kleio',          'Ishani',        1234567890,  'Eforst56@superrito.com','8 East Cactus Drive','Reynoldsburg',32137,1001,'Basement');

INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1002,    'Divya',          'Tiwlip',        1234567890,  'Ablemplaid48@cuvox.de','115 E. Rock Creek Circle','Palm Coast',32137,1002,'Top Floor');

INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1003,    'Roland',         'Sebastian',     1234567890,  'Abse1957@einrot.com','679 Pacific Dr.','Reading',01867,1003,'');

INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1004,    'Indira',         'Rajeev',        1234567890,  'Thut1953@superrito.com','43 West Shady Court','Snohomish',98290,1004,'Main Building');

INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1005,    'Ionas',          'Filipina',      1234567890,  'Derry1942@rhyta.com','721 Oak Lane','Poughkeepsie',12601,1005,'Main Building');

INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1006,    'Nirmal',         'Doncho',        1234567890,  'Gorry1980@fleckens.hu','24 Paris Hill Road','South Portland',04106,1006,'Basement');

INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1007,    'Uranus',         'Eusebius',      1234567890,  'Capt1929@rhyta.com','533 Bank Lane','Williamsburg',23185,1007,'East Wing');

INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1008,    'Zulfaqar',       'Uduak',         1234567890,  'Olde1931@einrot.com','9192 Sussex Dr.','Camas',98607,1008,'Secound Building');

INSERT INTO Staff (StaffID, Staff_First_Name, Staff_Last_Name, Staff_Phone, Staff_Email, Staff_Addess, Staff_City, Staff_Zip, FK_DepartmentID, Staff_Office_location) 
           VALUES (1009,    'Patroclus',      'Hakan',         1234567890,  'Amen1978@superrito.com','718 Littleton Road','Fort Washington',20744,1009,'Main Building');

INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1000, 1002, 'Professional training center');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1001, 1002, 'Marketing ');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1002, 1002, 'Pediatric center');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1003, 1002, 'Professional training center');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1004, 1003, 'Executive administration');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1005, 1003, 'Accounting');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1006, 1003, 'Critical care');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1007, 1004, 'Information systems');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1008, 1004, 'Critical care');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1009, 1004, 'Pediatric center');
               
INSERT INTO Departments (DepartmentID, FK_HospitalID, Department_Name) 
               VALUES (1010, 1004, 'Professional training center');

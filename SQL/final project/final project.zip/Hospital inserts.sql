INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1000,       'Magic Medicine','USA',          '123 Awesome St', 'Accident',    21520,        'English');

INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1001,       'Happy Healthy','USA',          '42 Second St',    'Dogtown',     35068,        'English');
            
INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1002,       'Brave',       'USA',            '564 Hospital St','Fearnot',     17968,        'English');
               
INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1003,       '1st OutReachMD','Mongolia',     '1 First st',     'Moron',        '',          'Mongolian');
               
INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1004,       'Serious Care','Belgium',        '66 Stern Dr',    'Silly',       7830,         'Dutch');
               
INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1005,       'Supper Meidical','Turkey',      '5649 Hero St',   'Batman',      72000,        'Turkish');
               
INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1006,       'Mediocer Medicine','USA',       '123 LetDown St', 'Accident',    21520,        'English');

INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1007,       'Crucial Compashion','Uganda',   '646 third St',   'Kampala',     '',           'English');
            
INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1008,'Wyoming County Community Health System','USA','400 N Main St','Warsaw', 14569,        'English');
               
INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1009,       '9th OutReachMD','Nepal',        '1 First st',     'Kathmandu',   '',           'Nepali');
               
INSERT INTO Hospitals (HospitalID, Hospital_Name, Hospital_Country, Hospital_Address, Hospital_City, Hospital_Zip, Hospital_Primary_Language) 
               VALUES (1010,       'No1 Hospital','kazakhstan ',    '66 apple Dr',    'almaty',      '',           'kazakh');